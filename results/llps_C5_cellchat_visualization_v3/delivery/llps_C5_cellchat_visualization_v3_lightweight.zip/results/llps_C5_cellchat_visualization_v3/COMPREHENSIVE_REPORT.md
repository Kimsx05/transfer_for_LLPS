# LLPS C5 CellChat 可视化与多证据整合 v3

日期：2026-11-26。正式主线为完整 C5，tumor-only、min.cells=20；10/30仅作敏感性分析。seed=123。没有重跑CellChat、NicheNet、cell2location或空间模型，也没有重建high/low分组。

已整理 186 张独立图形，其中旧版原图 28 张。图形类别、数据、脚本和局限逐张列于 FIGURE_INDEX.csv；浏览入口为 FIGURE_GALLERY.html。

## 1. 正式 v2 的主要结果

59份样本、42名患者和716个正式C5细胞的既有映射沿用不变。全样本C5可评估数不能代替本轮肿瘤分母；本轮如下：

| min_cells | specimens | patients |
| --- | --- | --- |
| 10 | 15 | 15 |
| 20 | 13 | 13 |
| 30 | 10 | 10 |

严格过滤规则为 n > min.cells，阈值20实际至少21个细胞。所有主图仅用正式v2的原14群，原Fibro/Pericyte C0–C6不拆分、不合并；没有套用high/low新增Pericyte网络。v2完整参数为CellChat2.1.2、完整human DB、truncatedMean、trim0.1、population.size=FALSE、nboot100、raw.use=TRUE、seed123，本轮只读现有结果。

主结论是C5具有较广泛的基质/黏附相关通讯推断，Endothelial兼具较强双向强度与较充分覆盖；它是值得独立验证的伙伴，并非已证实的唯一或特异靶细胞。

## 2. 哪些细胞群通讯最强

| direction | partner | eligible_patients | patient_condition_median | patient_condition_q25 | patient_condition_q75 |
| --- | --- | --- | --- | --- | --- |
| incoming | Endothelial | 12 | 2.039 | 1.446 | 2.693 |
| incoming | Epithelial | 9 | 0.7518 | 0.5608 | 1.135 |
| incoming | Myeloid | 13 | 0.5422 | 0.4179 | 0.6374 |
| incoming | Mast | 9 | 0.503 | 0.3987 | 0.5234 |
| incoming | T_NK | 12 | 0.3663 | 0.2889 | 0.4276 |
| incoming | B | 11 | 0.3073 | 0.1972 | 0.4404 |
| incoming | Plasma | 9 | 0.1596 | 0.05899 | 0.1694 |
| outgoing | Endothelial | 12 | 3.577 | 3.159 | 4.622 |
| outgoing | T_NK | 12 | 3.231 | 2.695 | 3.472 |
| outgoing | Mast | 9 | 3.092 | 2.52 | 3.151 |
| outgoing | Myeloid | 13 | 2.8 | 2.4 | 3.385 |
| outgoing | Epithelial | 9 | 2.71 | 2.623 | 5.025 |
| outgoing | B | 11 | 2.37 | 2.127 | 2.576 |
| outgoing | Plasma | 9 | 1.258 | 0.9564 | 1.39 |

在七个非fibro伙伴中，Endothelial的outgoing与incoming中位数分别为3.5765和2.0388，均为12名eligible患者；outgoing随后为T/NK、Mast、Myeloid、Epithelial等。完整14群中若干fibro边更强，例如C5→C6约5.055，但仅4名患者；不能把强度名次解释为细胞特异偏好。不同边分母不同，没有进行伙伴间正式差异检验。圈图保留所有节点，节点大小相同，五张圈图使用同一强度范围和映射；未显示的NA/0详见CSV。

## 3. 为什么聚焦Endothelial

理由是可检验性及证据结构，而不是事后挑选某条显著轴：12名患者来自GSE222315的5名及InhouseData的7名，双向网络较强，多个ECM/调节轴具有重复支持，且已有内皮响应与空间资料可用于反证和核查。Epithelial仅9名eligible患者，不同分母限制简单比较。C5的既有功能证据集中于ECM/胶原重塑与EMT基因集，不能将富集直接解释为EndMT或促血管生成。

既有llps_C5_parallel_v1中，C5肿瘤富集对低分母和dataset敏感；四队列调整OS模型均未支持独立C5预后关联。其DEG/GSEA来自历史分析，本轮不重新检验。旧丰度研究的样本集合不同，不拿53个历史丰度样本替代当前59份atlas映射。

## 4. 内皮主要pathway与LR

| direction | feature | positive_patients | eligible_patients | patient_condition_median |
| --- | --- | --- | --- | --- |
| outgoing | COLLAGEN | 12 | 12 | 1.69 |
| incoming | COLLAGEN | 12 | 12 | 0.9619 |
| outgoing | LAMININ | 12 | 12 | 0.572 |
| outgoing | FN1 | 12 | 12 | 0.32 |
| incoming | LAMININ | 12 | 12 | 0.2928 |
| outgoing | MK | 12 | 12 | 0.102 |
| incoming | CD99 | 12 | 12 | 0.09727 |
| outgoing | CD99 | 12 | 12 | 0.09421 |
| incoming | FN1 | 11 | 12 | 0.08442 |
| incoming | CypA | 10 | 12 | 0.08362 |
| outgoing | VEGF | 12 | 12 | 0.0829 |
| outgoing | APP | 10 | 12 | 0.06219 |
| outgoing | ADGRG | 12 | 12 | 0.05229 |
| outgoing | THBS | 11 | 12 | 0.04909 |
| outgoing | CypA | 9 | 12 | 0.04813 |
| outgoing | MIF | 11 | 12 | 0.04656 |
| outgoing | ANGPTL | 10 | 12 | 0.0371 |
| incoming | APP | 9 | 12 | 0.03442 |
| outgoing | ncWNT | 10 | 12 | 0.03298 |
| outgoing | SEMA3 | 12 | 12 | 0.03103 |

COLLAGEN、LAMININ、FN1占主要绝对强度；MK、VEGF、SEMA3等另有候选。PERIOSTIN在当前数据库属于Secreted Signaling，不因POSTN是基质相关蛋白而改为ECM类别。MDK的实际通路名为MK，ADM为CALCR，TGF-beta为TGFb。全部候选命名和类别在00_input_audit/pathway_candidate_audit.csv。

| direction | feature | positive_patients | eligible_patients | positive_datasets | patient_condition_median | status |
| --- | --- | --- | --- | --- | --- | --- |
| outgoing | ADM_CALCRL | 12 | 12 | 2 | 0.02191 | DETECTED |
| outgoing | COL1A1_ITGA1_ITGB1 | 12 | 12 | 2 | 0.1814 | DETECTED |
| outgoing | COL1A2_ITGA1_ITGB1 | 12 | 12 | 2 | 0.1806 | DETECTED |
| incoming | COL4A1_ITGA11_ITGB1 | 12 | 12 | 2 | 0.1107 | DETECTED |
| incoming | COL4A2_ITGA11_ITGB1 | 12 | 12 | 2 | 0.1071 | DETECTED |
| outgoing | COL6A2_ITGA1_ITGB1 | 12 | 12 | 2 | 0.09778 | DETECTED |
| outgoing | COL6A3_ITGA1_ITGB1 | 12 | 12 | 2 | 0.1088 | DETECTED |
| outgoing | FN1_ITGA5_ITGB1 | 12 | 12 | 2 | 0.1435 | DETECTED |
| outgoing | HSPG2_DAG1 | 7 | 12 | 2 | 0.0004638 | DETECTED |
| outgoing | MDK_ITGA6_ITGB1 | 12 | 12 | 2 | 0.06296 | DETECTED |
| incoming | PDGFB_PDGFRA | 12 | 12 | 2 | 0.002813 | DETECTED |
| incoming | PDGFB_PDGFRB | 12 | 12 | 2 | 0.004682 | DETECTED |
| incoming | PDGFD_PDGFRB | 12 | 12 | 2 | 0.002397 | DETECTED |
| outgoing | POSTN_ITGAV_ITGB3 | 5 | 12 | 2 | 0 | DETECTED |
| outgoing | POSTN_ITGAV_ITGB5 | 6 | 12 | 2 | 0.001004 | DETECTED |
| outgoing | SEMA3C_NRP1_PLXNA2 | 12 | 12 | 2 | 0.006755 | DETECTED |
| outgoing | SEMA3C_PLXND1 | 12 | 12 | 2 | 0.005708 | DETECTED |
| outgoing | VEGFA_VEGFR1 | 11 | 12 | 2 | 0.01459 | DETECTED |
| outgoing | VEGFA_VEGFR1R2 | 11 | 12 | 2 | 0.01463 | DETECTED |
| outgoing | VEGFA_VEGFR2 | 11 | 12 | 2 | 0.008554 | DETECTED |
| outgoing | WNT2_FZD4_LRP6 | 12 | 12 | 2 | 0.0004244 | DETECTED |

每条LR的完整受体亚基来自正式DB复杂体展开表。气泡面积表示患者检出率，旁注为阳性/有效患者；颜色为包含真实零值的患者强度中位数，不是P值。颜色为0且有气泡是可能的：不足半数患者检出，或患者多取材的中位强度为0。数据库中未定义的轴应标记NOT_IN_DB，不填作未检出；本轮明确请求的轴均能匹配，其他展开的SPP1/THY1候选有真实未检出结果并保留。

## 5. 表达、CellChat与NicheNet如何共同支持候选

| gene | C5_C0_difference | historical_C5_rest_FDR | selected_axis | CellChat_positive | CellChat_eligible | CellChat_strength | NN_SetB_rank | NN_LOPO_top10 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| POSTN | 0.9353 | 2.338e-05 | POSTN_ITGAV_ITGB5 | 6 | 12 | 0.001004 | 1 | 0.9524 |
| FN1 | 0.8676 | 0.01747 | FN1_ITGA5_ITGB1 | 12 | 12 | 0.1435 | 116 | 0 |
| COL1A1 | 1.186 | 0.0001556 | COL1A1_ITGA1_ITGB1 | 12 | 12 | 0.1814 | 149 | 0 |
| COL1A2 | 0.8433 | 0.0004798 | COL1A2_ITGA1_ITGB1 | 12 | 12 | 0.1806 | 95 | 0 |
| COL3A1 | 1.084 | 0.0003041 | COL3A1_ADGRG1 | 12 | 12 | 0.03193 | 20 | 0 |
| COL6A2 | 0.5419 | 0.005452 | COL6A2_ITGA1_ITGB1 | 12 | 12 | 0.09778 | 68 | 0 |
| COL6A3 | 0.322 | 0.0002554 | COL6A3_ITGA1_ITGB1 | 12 | 12 | 0.1088 | 25 | 0 |
| HSPG2 | 0.08368 | 0.0002953 | HSPG2_DAG1 | 7 | 12 | 0.0004638 | 194 | 0 |
| MDK | 0.224 | 0.008316 | MDK_ITGA6_ITGB1 | 12 | 12 | 0.06296 | 222 | 0 |
| ADM | 0.02166 | 0.04407 | ADM_CALCRL | 12 | 12 | 0.02191 | 197 | 0 |
| SEMA3C | -0.004734 | 0.1149 | SEMA3C_NRP1_PLXNA2 | 12 | 12 | 0.006755 | 89 | 0 |
| WNT2 | 0.2955 | 0.0007951 | WNT2_FZD4_LRP6 | 12 | 12 | 0.0004244 | 12 | 0.09524 |
| VEGFA | -0.1282 | 0.6902 | VEGFA_VEGFR1R2 | 11 | 12 | 0.01463 | 42 | 0 |
| INHBA | 0.5484 | 0.0002182 | INHBA_ACVR1B_ACVR2A | 3 | 12 | 0 | 2 | 1 |
| ANGPTL4 | 0 | 0.6087 | ANGPTL4_CDH5 | 5 | 12 | 0 | 3 | 0.9048 |
| TGFB1 | -0.04953 | 0.7034 | TGFB1_ACVR1_TGFBR1 | 2 | 12 | 0 | 5 | 0.9048 |
| IGF2 | 0 | NA | IGF2_IGF2R | 3 | 12 | 0 | 4 | 0.8571 |
| TGFB2 | -0.08626 | 0.01743 | TGFB2_ACVR1_TGFBR1 | 4 | 12 | 0 | 7 | 0.6667 |
| WNT5A | 0.5933 | 0.0001556 | WNT5A_MCAM | 10 | 12 | 0.02141 | 90 | 0 |
| TNFSF12 | 0.1455 | 0.964 | TNFSF12_TNFRSF12A | 1 | 12 | 0 | 201 | 0.04762 |

不建立加权总分，按不同实验问题分层：FN1/胶原轴具有较广患者通讯覆盖及表达支持，适合检验基质–受体轴，但nominal NicheNet排名不一定高。POSTN及INHBA具有亚群表达和较高nominal activity排名，但对应LR覆盖仅6/12与3/12，不能称全体患者共同机制。WNT2可作为低概率、广覆盖且nominal Set B rank12的补充候选。MDK/ADM虽广泛检出，其Set B排名靠后；HSPG2的表达支持不能替代较有限的HSPG2–DAG1覆盖和较低activity排名。SEMA3C具有通讯线索，但历史C5-vs-rest pseudobulk FDR约0.115，不能声称已有明确C5特异表达富集。

“有NicheNet支持”必须指明定义：进入可评估ligand universe、有prior边、正activity、排名靠前和随机背景显著性不是同一概念。POSTN的Set B排名1、LOPO top10约20/21，但既有随机背景BH约0.506；不能包装成FDR显著实测内皮响应。标准Hallmark程序是先验，Set A/B/C是名义响应集，旧内皮主模型EMT/Angiogenesis/TGF-beta未通过BH<0.10。

| source | program | ligands | targets | missing_prior |
| --- | --- | --- | --- | --- |
| standard | HALLMARK_ANGIOGENESIS | 246 | 20 | 0 |
| standard | HALLMARK_TGF_BETA_SIGNALING | 246 | 47 | 0 |
| standard | GOBP_BLOOD_VESSEL_REMODELING | 246 | 21 | 0 |
| nominal | Set_A | 246 | 28 | 0 |
| nominal | Set_A_noECM | 246 | 27 | 0 |
| nominal | Set_B | 246 | 123 | 0 |
| nominal | Set_B_noECM | 246 | 122 | 0 |
| nominal | Set_C | 246 | 302 | 0 |
| nominal | Set_C_noECM | 246 | 301 | 0 |
| nominal | EMT | 246 | 98 | 0 |

NicheNet图覆盖三个标准程序、Set A/B/C及noECM、EMT。Set B全部246项activity分7页；LT完整246×123矩阵保存在tables，完整目标图分4页，显示top20加可用重点配体；精简版选35个prior权重较大的target。LR prior图显示当前展示配体及表达较充分的30个受体，所有prior边另存完整表。0/1表示先验网络有无记录，不是单细胞通讯检出。没有重新计算activity、排名、LOPO或响应DEG。

## 6. 患者与跨队列支持

COL1A1/2、COL6A2/3–ITGA1/ITGB1、FN1–ITGA5/ITGB1、MDK–ITGA6/ITGB1、ADM–CALCRL及多个SEMA3C/WNT2轴在主阈值内皮方向有12/12患者支持，来自两个队列。内皮→C5的PDGFB–PDGFRB/PDGFRA、PDGFD–PDGFRB以及COL4A1/2–ITGA11/ITGB1也有广泛覆盖。完整分层强度及患者分母位于Endothelial_core_LR_all_thresholds.csv.gz和09_sensitivity_analysis。

min.cells10/20/30改变样本及伙伴的eligibility；共同样本的概率来自同一次上游推断，不能称三次独立验证。InhouseData与GSE222315的临床分期构成不同，不能将队列差异直接解释为MIBC/NMIBC生物学差异。没有开展Normal vs Tumor差异通讯检验。

共同样本C5 vs C0结果如下，区间为IQR而非CI，未新增显著性检验：

| partner | direction | n_patients | median_difference | q25 | q75 |
| --- | --- | --- | --- | --- | --- |
| Epithelial | outgoing | 4 | 0.779 | 0.5066 | 0.9886 |
| Epithelial | incoming | 4 | 0.2344 | 0.1886 | 0.3596 |
| Endothelial | outgoing | 5 | 0.4419 | 0.2822 | 0.8131 |
| Endothelial | incoming | 5 | 0.218 | 0.09811 | 0.6047 |
| Myeloid | outgoing | 6 | 0.4638 | 0.2767 | 0.5663 |
| Myeloid | incoming | 6 | 0.07861 | 0.009065 | 0.1717 |
| T_NK | outgoing | 6 | 0.3593 | 0.2351 | 0.5386 |
| T_NK | incoming | 6 | 0.06174 | 0.008168 | 0.2001 |

全部C1–C4、C6共同患者差值亦保留。不能以全体C5和全体C0不同患者组成的中位数直接相减。

## 7. 矛盾与阴性证据

POSTN/INHBA/ANGPTL4/IGF2/TGFB1的高名义NicheNet排名与较低实际LR患者覆盖不一致；FN1/胶原的高CellChat强度与较低部分NicheNet排名也不一致，体现两种方法衡量的对象不同。所有阴性轴和NA均保留。

空间证据不能当作C5特异验证：63张切片、265002 spots的Five-gene program不是已确认的C5丰度，正式定位NO-GO仍有效。29名已确认患者中，Endothelial原始空间关联约0.155，组成/深度调整后约−0.041 (95%CI −0.082至−0.022)；局部HH与整体负向结构可以共存。没有伙伴达到“稳健条件正向空间支持”的验证标准。Five–LLPS的调整相关约0.107属于混合spot程序共现，不是完整C5内部机制。

整合图的空间列仅使用已有配体轴评估，未做过的候选如POSTN该轴为NA，不将Five-gene空间关联复制给每个候选。更完整的负向伙伴证据见spatial_partner_adjustment_context。受体表达采用最低亚基边际检测率，并不是复杂体联合共表达率。

## 8. 旧high/low图是否全部处理

全部 28 张PNG均逐项登记，原PDF、PNG和绘图数据完整归档至10_legacy_highlow_exploratory，SHA256用于核对。圈图/热图/LR图/森林图以v2数据重新制作；连续LLPS相关与细胞/患者散点保留为探索补充；技术QC及旧high/low网络仅归档，没有移植数值或重新解释统计单位。对应关系见legacy_figure_mapping.csv。

## 9. 主图和补充材料建议

主图候选：两张七伙伴圈图、C5-focused和Fibro–TME双三角图、强度IQR森林图、Endothelial双向pathway精简图、内皮方向LR数据驱动与假说版本、patient-balanced配体/受体表达图、多证据整合图。名义Set B activity/LT图可作为机制假说展示，但图注必须保留名义响应与先验性质。

补充：完整14群网络、有效患者数热图、全量候选/完整目标页、七伙伴患者分布、其他fibro共同患者对照、阈值/队列重复性、全部标准和noECM NicheNet定义、空间调整反转。旧high/low及连续LLPS关联独立作为Exploratory legacy，不能取代完整C5主线。

## 10. 本轮新增了什么

新增均为描述性提取/汇总：14群LR count的患者中位数；LR按四类求和与patient-first组成；共同specimen的亚群差值再汇总患者；从43份肿瘤RNA缓存提取候选表达、检测率和小提琴所需六基因细胞值；patient-balanced表达及≥5细胞共同specimen的C5-vs其他群表达差；从既有NicheNet prior读取冻结target矩阵；图形筛选、排序、整合和独立QC。未新增CellChat/NicheNet推断、pseudobulk DE模型、空间统计、高低分组或假设检验。

## 统计规则与限制

通信强度=同一患者×clinical_group内合格specimen的中位数；跨患者展示中位数和IQR。相同患者的Normal/Tumor不合并。检出=至少一份eligible specimen的原生通信为阳性，分母为独立eligible患者。强度汇总仍沿用v2的patient-condition单位；本轮肿瘤集合已核验无患者跨两个肿瘤临床条件重复。NA只在ineligible/缺失，eligible未检出为0。样本内CellChat置换P仅用于原有检出定义，不解释为患者级显著性。

表达图另有自己的覆盖分母：常规图为全部肿瘤细胞描述；balanced版本先在同一患者条件内汇总取材细胞，再给患者等权，保留至少1细胞并在数据列给n；共同表达比较要求每份specimen两群各至少5细胞，计算患者内差值，不是重新拟合DE。实际normalized RNA没有Z-score或integrated/scaled替代。

相对组成先按specimen内eligible边计算各类别/总强度，零总强度的比例为NA；再在患者条件内取中位数、跨患者取均值展示。不是用不同分母的类别汇总中位数相除。完整网络图的对角线主动排除，灰色对角线属于self omitted，区别于灰色ineligible。

网络圈图、三角图、气泡、森林及多证据图没有对应skill专用模板，按本轮需求用ggplot构建，复用skill主题、配色和jin_export；小提琴直接使用正式Violin_distribution模板。白底矢量PDF和300dpi PNG，完整PDF采用基本文件名，另有panel_only/legend_only。没有额外生成重复_full.pdf。每图在索引中对应脚本和完整绘图数据。

所有科学来源及hash见00_input_audit/source_inventory.csv，最终QC见FINAL_QC_REPORT.md。GitHub交付状态见delivery/UPLOAD_STATUS.md；失败不会误报已上传。
